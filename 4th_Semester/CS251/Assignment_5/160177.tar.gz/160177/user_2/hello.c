#include <stdio.h>

void microkernel_sendmsg(char *);

void main(){
  printf("Helloworld!\n");
  printf("This must be a monolithic design\n");
  printf("No, This should be a micro design (It is better!!)\n");
  microkernel_sendmsg("is more portable");
}

void microkernel_sendmsg(char *a){
  printf("microkernel: %s\n", a);
}
